const db = require('./db')

const Post = db.sequelize.define('prodcabs', {

    cod: {
        type: db.Sequelize.STRING 
    },
    produto: {
        type: db.Sequelize.TEXT
    },
    propriedade: {
        type: db.Sequelize.TEXT
    },
    linha: {
        type: db.Sequelize.TEXT
    }
})

//Post.sync({force:true})//execute uma unica vez e depois apague ou comente se nao 
module.exports = Post //acesso o model post atraves de outros arquivos 

